% rUN THIS ONCE run pa_wavrecord(1,1,48000*5, 48000);

clear all
close all
clc
Fs = 48e3;
t = 10;

port = input("Which COM port is used?");
com = int2str(port);
P = ['\\.\COM', com];
comport = P; % the actual COM port

result = EPOCommunications('open',comport);

    EPOCommunications('transmit', 'B5000');
    % set the bit frequency
    EPOCommunications('transmit', 'F15000');
    % set the carrier frequency
    EPOCommunications('transmit', 'R2500');
    % set the repetition count
    EPOCommunications('transmit', 'C0xaa55aa55');
    % set the audio code
    EPOCommunications('transmit', 'A1');
% 
% 
% data = pa_wavrecord(1,5,Fs*t, 48000);
% figure(1)
% plot(data)
% legend
% save('data_audio(1,1)', data);