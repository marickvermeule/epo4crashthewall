%Date:      19-05-2022
%Author:    Dimme, 
%           based on example by EPO4 teaching team 2016: "EPO4_playrec_example.m"
%      
%Descr:     Simple script which can be used to set the beacon settings and 
%           record audio.  This version uses playrec instead of pa_wavrecord. 
%           The advantage of using playrec is that it possibly introduces
%           less delay compared to pa_wavrecord.
%           
%           Note that you need to set the channels and Fs based on the location where you measure.
%               For office:         channels = 14:19,   Fs = 48 kHz
%               For tellegen{1,2}:  channels = 1:5,     Fs = 44.1 kHz
%           Please confirm for yourself that these settings work properly. 
%
%           USE AT OWN RISK :). Please let us know if there is something wrong.
%      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Comments from original file:
% Playrec - an alternative to pa_wavrecord(.)
% This example script shows how to use playrec to record upto 5 mics.
% Source files can be downloaded from this link below
% http://www.playrec.co.uk/index.html
% 
% We recommend to compile the source files yourself. Nevertheless,
% the precompiled binary files (e.g., for windows use the *.mexw64 file) 
% from the link below
% https://github.com/Janwillhaus/Playrec-Binaries
%
%- for the list of commands for playrec, call playrec without any options      
%- for more detailed explanation of a command use playrec('help','command')
%  
% EPO-4 project, 27-05-2016, TU Delft.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear measurements

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%step 0: user settings
group_name = 'TA';
comport = '\\.\COM17';
channels = 15:19;       %1:5 for tellegen{1,2}; 15:19 for office; channels on which you record
Fs = 48000;             %sample frequency [Hz], 48 kHz for office, <??> for the other 2
second_rec = 5;         %time of recording [s]
bitcode = 'aa55aa55';   %transmitted bits [-], e.g. 'aa55aa55'
F_carrier = 15000;      %carrier frequency [Hz], e.g. 8000   
F_bit = 5000;           %bit frequency [Hz], e.g. 5000
C_repetition = 2500;    %repetition count [-], e.g. 2500
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%step 1: establish communication, set beacon settings
resultOpen = EPOCommunications('open', comport)


% EPOCommunications('transmit', ['C0x', bitcode]);
% EPOCommunications('transmit', ['F', int2str(F_carrier)]);
% EPOCommunications('transmit', ['B', int2str(F_bit)]);
% EPOCommunications('transmit', ['R', int2str(C_repetition)]);
    EPOCommunications('transmit', 'B5000');
    % set the bit frequency
    EPOCommunications('transmit', 'F15000');
    % set the carrier frequency
    EPOCommunications('transmit', 'R2500');
    % set the repetition count
    EPOCommunications('transmit', 'C0xaa55aa55');
    % set the audio code
EPOCommunications('transmit', 'A1');

%Step 2: initialise audiocard
fnc_init_playrec(Fs);  
N = round(second_rec*Fs); %nbr of samples to be recorded

%step 3: make measurements. 
quit = 'n';
i = 1;
while quit ~= 'y'
    disp("Place KITT at the desired location.")
    measurements{i,1} = input("Please specify KITT coordinates as [x, y].");
    
    disp("Taking measurements")
    EPOCommunications('transmit', 'A1');
    measurements{i,2} =  fnc_record_playrec(N, channels);
    EPOCommunications('transmit', 'A0');

    quit = input("If you want to quit, type 'y'. If otherwise, type 'n'");
    i = i+1;
end

resultClose = EPOCommunications('close')
playrec('reset');

%step 4: save workspace
c = clock;
save([group_name, '-', date, '-', num2str(c(4)), '_', num2str(c(5)), '.mat'])

%step 5: some plotting
disp("Plotting...")
[nMeas, ~] = size(measurements);
for i = 1:nMeas
    data = measurements{i,2};
    loc = measurements{i,1};
    figure
    plot(data)
    legend
    title(['location: (x, y) = (', num2str(loc(1)), ', ', num2str(loc(2)), ')'])  
    xlabel('sample [-]')
    ylabel('amplitude []')
end
