%Date:      19-05-2022
%Author:    EPO-4 teaching team, edited by Dimme 
%Descr:`    initialise the fast recording function.
%
%           The advantage of using playrec is that it possibly introduces
%           less delay than pa_wavrecord does.

function fnc_init_playrec(Fs)
    if playrec('isInitialised')
        playrec('reset');
    end
    
    %get list of devices, select proper device
    devs = playrec('getDevices');
    for id=1:size(devs,2)
        if(strcmp('Microphone (Scarlett 18i20 USB)',devs(id).name)) %Tellegen 2: FocusRite Scarrlett 18i20
            if(devs(id).defaultHighOutputLatency==0.04)             
                break;
            end
        elseif(strcmp('ASIO MADIface USB',devs(id).name))   %Office:    RME Fireface UFX+
            break;
        elseif(strcmp('ASIO4ALL v2',devs(id).name))         %Tellegen1: presonus audiobox 1818vsl
            break;
        end
    end
    devId=devs(id).deviceID;

    %initialise
    playrec('init', Fs, -1, devId);
    if ~playrec('isInitialised')
        error ('Failed to initialise device at any sample rate');
    end
end