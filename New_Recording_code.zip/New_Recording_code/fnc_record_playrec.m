%Date:      19-05-2022
%Author:    EPO-4 teaching team, edited by Dimme 
%Descr:`    use playrec to record data.
%           Inputs: N, the number of samples to be recorded; maxChannel:
%                   the number of channels.
%           Output: data, the recording.

function data = fnc_record_playrec(N, channels)
    page=playrec('rec',N, channels);  % start recording in a new buffer page
	while(~playrec('isFinished'))           % Wait till recording is done 
                                            %(can also be done by turning on the block option)
    end
    data = double(playrec('getRec',page));  % get the data;
    playrec('delPage');                     % delete the page (can be done every few cycle
end